StepUp Exception: undefined method `parse' for Time:Class
